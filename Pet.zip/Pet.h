#ifndef PET_H
#define PET_H

#include <iostream>
#include <string>
using namespace std;

class Pet
{
public:
    Pet();
    Pet(string, int, int, int);
    string GetAction();
    int GetFeeling();
    int GetAppetite(); // wil determine string by number, for example if we return 5 or > pet is hungry
    int GetHour(); // for every action we we will add 2 hours, every 6 hours pet will be hungry and every 12 pet will be sleepy

    void SetAction(int); // set action
    void SetFeeling(int); // how is pet feeling
    void SetAppetite(int); // how hungry
    void SetHour(int); // military time hour
    
    void play();
    void hunting();
    void traveling();

    virtual void PrintInfo() = 0;

private:
    string action;
    int feeling;
    int appetite;
    int hour;
};

#endif