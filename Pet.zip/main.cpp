#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main()
{
    cout << endl;
    cout << "                                                       Tamagotchi Pet Game" << endl;
    cout << endl;
    cout << endl;
    cout << "                                       Please select what animal you'd like to interact with!"<< endl;
    cout << "                                               Select an animal to adopt and interact with." << endl;

    cout << "                                                   The following images are the pets available for adoption"<< endl;
    cout << endl << endl;

        cout <<"    ,_    _                 "<<"                  ______________                              "<<"            __        "<<endl;
        cout <<"    |\\\_,~/|               "<<"             ,===:'.,            `-._                         "<<"             /  \\       "<<endl;
        cout <<"    / _  _ |    ,--.        "<<"                 `:.`---.__         `-._                      "<<"          / ..|\\      "<<endl;
        cout <<"   (  @  @ )   / ,-'        "<<"                   `:.     `--.         `.                    "<<"         (_\\  |_)     "<<endl;
        cout <<"    \  _T_/-._( (           "<<"                      \\.        `.         `.                "<<"           /  \\@'       "<<endl;
        cout <<"    /         `. \          "<<"             (,,(,     \\.         `.   ____,-`.,             "<<"          /     \\       "<<endl;
        cout <<"   |         _  \ |         "<<"          (,'     `/    \\.   ,--.___`.'                      "<<"      _  /  `   |       "<<endl;
        cout <<"    \ \ ,  /      |         "<<"      ,  ,'  ,--.  `,     \\.;'         `                     "<<"       \\\\/  \\  | _\\      "<<endl;
        cout <<"     || |-_\__   /          "<<"       `{D, {    \\  :    \\;                                 "<< "        \\   /_ || \\\\_      "<<endl;
        cout <<"    ((_/`(____,-'           "<<"       V,,'    /  /      //                                   "<<"      \\____)|_) \\_)    "<<endl;
        cout <<"                            "<<"         j;;    /  ,' ,-//.    ,---.      ,                   "<<endl;
        cout <<"                            "<<"         \\;'   /  ,' /  _   \\  /  _   \\   ,'/              "<<endl;
        cout <<"        CAT                    "<<"              \    `'  /  \\  `'  /  \\  `.' /             "<<"            DOG          "<< endl;
        cout <<"                            "<<"                `.___,'   `.__,'   `.__,'                     "<<endl;
cout << endl;
cout << endl;
        cout << "                                                       DRAGON                                                                    ";
cout << endl << endl << endl<< endl;
cout << "What Pet would you like to adopt and interact with?"<<endl;
cout << "Please input your selected pet! CAT, DRAGON, or DOG " << endl;
string pet;
cin >> pet;
system("cls");

cout << "The selected pet is " << pet << endl << endl;
string sentence;
if(pet=="CAT")
{
    ifstream catImage("CatImage.txt");
    while(!catImage.eof())
    {
        getline(catImage,sentence);
        cout << sentence<< endl;

    }
}
if(pet == "DOG")
{
    ifstream dogImage("DogImage.txt");
    while(!dogImage.eof())
    {
        getline(dogImage,sentence);
        cout << sentence<< endl;

    }    
}
if(pet == "DRAGON")
{
    ifstream dragonImage("DragonImage.txt");
    while(!dragonImage.eof())
    {
        getline(dragonImage,sentence);
        cout << sentence<< endl;

    }
}


    
    
    
    
    
    return 0;


}