#include "Pet.h"
using namespace std;

Pet::Pet()
{
    int action=10;
    int feeling= 10;
    int appetite = 10; //"◼◼◼◼◼◼◼◼◼◼ 100%"
    int hour = 0;
}

Pet::Pet(string action, int feeling, int appetite, int hour)
{
    this->action=action;
    this->feeling=feeling;
    this->appetite=appetite;
    this->hour=hour;
}

string Pet::GetAction()
{
    return action;
}

int Pet::GetFeeling()
{
    return feeling;
}

int Pet::GetAppetite() // wil determine string by number, for example if we return 5 or > pet is hungry
{
    return appetite;
}
int Pet::GetHour()     // for every action we we will add 2 hours, every 6 hours pet will be hungry and every 12 pet will be sleepy
{
    return hour;
}
void Pet::SetAction(int _action)  // set action
{
    action = _action;
}
void Pet::SetFeeling(int _feeling) // how is pet feeling
{
    feeling = _feeling;
}
void Pet::SetAppetite(int _appetite)   // how hungry
{
    appetite = _appetite;
}
void Pet::SetHour(int _hour)      // military time hour
{
    hour = _hour;
}
void Pet::play(int _feeling)
{
    cout << "You have played with your pet";
    if(GetFeeling()+1 >=! 10)
    {
         feeling = _feeling;
    }
}
void Pet::hunting()
{

}
void Pet::traveling()
{

}
void Pet::PrintInfo()
{

}



